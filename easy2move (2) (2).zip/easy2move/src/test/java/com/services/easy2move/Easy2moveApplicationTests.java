package com.services.easy2move;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Easy2moveApplicationTests {

	@Test
	void contextLoads() {
	}

}
