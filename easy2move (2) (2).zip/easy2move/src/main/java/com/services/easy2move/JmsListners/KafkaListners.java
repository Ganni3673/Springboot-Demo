package com.services.easy2move.JmsListners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.services.easy2move.model.Easy2moveUsermodel;
import com.services.easy2move.service.Easy2moveUserService;
@Component
public class KafkaListners {

	@Autowired
	private Easy2moveUserService userservice;
	
	@KafkaListener(topics = "CodeDecodeTopic", groupId = "codedecode-group")
	public void listenToCodeDecodeKafkaTopic(String messageReceived) {
		System.out.println("Message received is " + messageReceived);
		userservice.sendMessageToTopic(messageReceived);
	}
	
	@KafkaListener(topics = "demo-topic", groupId = "codedecode-group")
	public void listenTouserdata(Easy2moveUsermodel messageReceived) {
		System.out.println("Message received is " + messageReceived.toString());
		userservice.senduserdata(messageReceived);
	}
}
