package com.services.easy2move.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.services.easy2move.model.Easy2moveUsermodel;
import com.services.easy2move.repository.Easy2moveUserRepository;

@Service
public class JwtUserdetailsService implements UserDetailsService{
	

	@Autowired
	private Easy2moveUserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Here we need to connect the user table for getting userdetails from DB
		Optional<Easy2moveUsermodel> user = userRepository.findbyMobNo(username);
		Easy2moveUsermodel userlist = null;
		if (user.isPresent()) {
			userlist = user.get();
		} else {
			 throw new UsernameNotFoundException("User not found with username: " + username); 
		 }
		return new User(userlist.getMobile_number(), userlist.getUser_password(), new ArrayList<>());

	}

}
