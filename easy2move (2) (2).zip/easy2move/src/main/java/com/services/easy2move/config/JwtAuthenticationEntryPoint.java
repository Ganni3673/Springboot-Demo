package com.services.easy2move.config;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.services.easy2move.json.Message;
@RestController
@Component
@ResponseStatus(value=HttpStatus.UNAUTHORIZED,reason = "Invalid token")
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint, Serializable {

	private static final long serialVersionUID = -7858869558953243875L;

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException {
		
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
		
	}

//	private Message returnmethod(HttpServletResponse res) {
//		Message msg = new Message();
//		msg.setMessage("unauthorized");
//		msg.setStatuscode(401);
//		return msg;
//		// TODO Auto-generated method stub
//		
//	}
}
