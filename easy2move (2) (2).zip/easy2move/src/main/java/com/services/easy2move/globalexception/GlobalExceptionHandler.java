package com.services.easy2move.globalexception;

import java.io.FileNotFoundException;
import java.nio.file.AccessDeniedException;
import java.util.NoSuchElementException;

import javax.persistence.NonUniqueResultException;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException.Unauthorized;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;
import org.springframework.web.context.request.WebRequest;

import com.services.easy2move.json.Message;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;

@RestControllerAdvice
public class GlobalExceptionHandler{

	@ExceptionHandler(NullPointerException.class)

	public @ResponseBody ResponseEntity<Message> nullvaluegetting(NullPointerException nullvalue) {
		Message msg = new Message();
		msg.setMessage("User details not found in DB please register as a new user");
		msg.setStatuscode(404);
		return new ResponseEntity<Message>(msg, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(NonUniqueResultException.class)

	public @ResponseBody ResponseEntity<Message> duplicatedata(NonUniqueResultException duplicate) {
		Message msg = new Message();
		msg.setMessage("User details found more than 1 reslut set in DB please validate data");
		msg.setStatuscode(400);
		return new ResponseEntity<Message>(msg, HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler(NoSuchElementException.class)

	public @ResponseBody ResponseEntity<Message> duplicatedata(NoSuchElementException novalue) {
		Message msg = new Message();
		msg.setMessage("No value present with your  details");
		msg.setStatuscode(400);
		return new ResponseEntity<Message>(msg, HttpStatus.BAD_REQUEST);

	}
	
	@ExceptionHandler(DataIntegrityViolationException.class)
	public @ResponseBody ResponseEntity<Message> duplicateusername(DataIntegrityViolationException novalue) {
		Message msg = new Message();
		msg.setMessage("username already used, so please change your username");
		msg.setStatuscode(400);
		return new ResponseEntity<Message>(msg, HttpStatus.BAD_REQUEST);

	}
	
	@ExceptionHandler(InternalServerError.class)
	public @ResponseBody ResponseEntity<Message> duplicateusername(InternalServerError in) {
		Message msg = new Message();
		msg.setMessage("unable to process your request, we are tyring to solve");
		msg.setStatuscode(500);
		return new ResponseEntity<Message>(msg, HttpStatus.INTERNAL_SERVER_ERROR);

	}
	
	@ExceptionHandler(FileNotFoundException.class)
	public @ResponseBody ResponseEntity<Message> filenotfound(FileNotFoundException in) {
		Message msg = new Message();
		msg.setMessage("unable to process your request, file not found");
		msg.setStatuscode(404);
		return new ResponseEntity<Message>(msg, HttpStatus.NOT_FOUND);

	}
	@ExceptionHandler(BadCredentialsException.class)
	public @ResponseBody ResponseEntity<Message> filenotfound(BadCredentialsException in) {
		Message msg = new Message();
		msg.setMessage("Invalid UserName and Password");
		msg.setStatuscode(401);
		return new ResponseEntity<Message>(msg, HttpStatus.UNAUTHORIZED);

	}
	@ExceptionHandler(UsernameNotFoundException.class)
	 @ResponseStatus(HttpStatus.NOT_FOUND)
	public @ResponseBody ResponseEntity<Message> filenotfound(UsernameNotFoundException in) {
		Message msg = new Message();
		msg.setMessage(in.getMessage());
		msg.setStatuscode(403);
		return new ResponseEntity<Message>(msg, HttpStatus.NOT_FOUND);

	}
	
	// Handling unwanted exceptions like calling unassigned http methods (instead of post calling get method)
	
	 @ExceptionHandler(value = {AccessDeniedException.class})
	 public ResponseEntity<Object> handleOtherExceptions(AccessDeniedException ex, WebRequest request) {
	  Message msg = new Message();
		msg.setMessage(ex.getMessage());
		msg.setStatuscode(400);
	  return new ResponseEntity<>(msg, new HttpHeaders(), HttpStatus.BAD_REQUEST);
	 }
	 
	 @ExceptionHandler(value={Unauthorized.class})
	 public ResponseEntity<Message> handleTokenException(Unauthorized e){
		 Message msg = new Message();
		 msg.setMessage("unauthorized");
		 msg.setStatuscode(401);
	     return new ResponseEntity<Message>(msg,HttpStatus.UNAUTHORIZED);
	 }
	 @ExceptionHandler(SignatureException.class)
	 public ResponseEntity<Message> handlesignatureException(SignatureException e){
		 Message msg = new Message();
		 msg.setMessage("unauthorized");
		 msg.setStatuscode(401);
	     return new ResponseEntity<Message>(msg,HttpStatus.UNAUTHORIZED);
	 }
	 
	 @ExceptionHandler(ExpiredJwtException.class)
	public @ResponseBody ResponseEntity<Message> serverException(ExpiredJwtException in) {
		Message msg = new Message();
		msg.setMessage(in.getMessage());
		msg.setStatuscode(401);
		return new ResponseEntity<Message>(msg, HttpStatus.UNAUTHORIZED);

	}


	 }
