package com.services.easy2move.model;


import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Data
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name="easy2move_users")
public class Easy2moveUsermodel{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private String username;
	private String mobile_number;
	private String email_id;
	private String user_password;
	private String city;
	private Boolean is_active;
	private Date created_on;
	private Date updated_on;

	@OneToMany(mappedBy = "userid")
	private List<UserBankDetailsModel> bankdetails;
	

}
