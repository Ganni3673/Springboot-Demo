package com.services.easy2move.json;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Easy2moveuserJson {

	private int id;
	private String name;
	private String username;
	private String mobile_number;
	private String email_id;
	private String user_password;
	private String city;
	private Boolean is_active;
}
