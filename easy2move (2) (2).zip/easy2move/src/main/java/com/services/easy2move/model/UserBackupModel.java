package com.services.easy2move.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@Getter
	@Setter
	@Entity
	@Table(name="user_backup")
	
	public class UserBackupModel {
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id;
		private String name;
		private String username;
		private String mobile_number;
		private String email_id;
		private String user_password;
		private String city;
		private Boolean is_active;
		private Date created_on;
		private Date updated_on;

}
