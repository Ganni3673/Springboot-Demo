package com.services.easy2move.json;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankDetailsJson {

	public String name;
	public String ifsc;
	public String account_number;
}
