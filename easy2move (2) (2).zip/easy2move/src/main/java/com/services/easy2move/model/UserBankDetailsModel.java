package com.services.easy2move.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name="user_accountdetails")
public class UserBankDetailsModel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String rzpcontactId;
	private String rzpbankrefId;
	private String mobile_number;
	private Boolean is_active;
	private Date created_on;
	private Date updated_on;
	private String email_id;
	
	@ManyToOne()
	@JoinColumn(name ="user_id")
	private Easy2moveUsermodel userid;
}
