package com.services.easy2move.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.services.easy2move.json.Easy2moveuserJson;
import com.services.easy2move.json.Message;
import com.services.easy2move.json.UserBankAccountJson;
import com.services.easy2move.json.UserContactJson;
import com.services.easy2move.model.UserModel;
import com.services.easy2move.service.Easy2moveUserService;

@RestController
@CrossOrigin
@RequestMapping(value = "user")
public class Easy2moveUserController {

	private static final Logger log = LoggerFactory.getLogger(Easy2moveUserController.class);

	@Autowired
	private Easy2moveUserService userservice;
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

		@GetMapping("v1/getusers")
	public ResponseEntity<String> getname(@RequestParam(value="name", required= true)String name,Principal principal) {
			String s ="";
			log.info(principal.getName());
		s=userservice.getnamebyusingMQ(name);
		return (new ResponseEntity<String>(s, HttpStatus.OK));
	}

	@PostMapping("v1/adduser")

	public @ResponseBody ResponseEntity<Easy2moveuserJson> adduser(@RequestBody Easy2moveuserJson userjson, Principal principal) {
		Easy2moveuserJson adduser = new Easy2moveuserJson();
		adduser = userservice.adduser(userjson);
		
		log.info("Inside service method data now returning" + adduser.toString());
		return new ResponseEntity<Easy2moveuserJson>(adduser, HttpStatus.ACCEPTED);
	}
	
	@PostMapping("v1/AdduserbyMQ")

	public @ResponseBody ResponseEntity<Easy2moveuserJson> adduserbyMQ(@RequestBody Easy2moveuserJson userjson) {
		Easy2moveuserJson adduser = new Easy2moveuserJson();
		adduser = userservice.AdduserByMQ(userjson);
		log.info("Inside service method data now returning" + adduser.toString());
		return new ResponseEntity<Easy2moveuserJson>(adduser, HttpStatus.ACCEPTED);
	}

	@GetMapping("v1/getuserbyMobNumber")
	public @ResponseBody ResponseEntity<Easy2moveuserJson> getuserbyMob(
			@RequestParam(value = "mobile", required = true) String mobileNo) {

		Easy2moveuserJson userlist = new Easy2moveuserJson();
		userlist = userservice.getuserdetails(mobileNo);

		return new ResponseEntity<>(userlist, HttpStatus.OK);
	}

	@PostMapping("v1/upload")
	    public ResponseEntity<Message> saveUsers(@RequestParam(value = "files") MultipartFile[] files) throws Exception {
		 Message msg  = new Message();  
		 for (MultipartFile file : files) {
	        	userservice.saveUsers(file);
	        	msg.setMessage("upload sucessfully");
	        	msg.setStatuscode(200); 
	        }
	        return new ResponseEntity<Message>(msg, HttpStatus.OK);
	    }
	
	@GetMapping("v1/getuserlist")
	public @ResponseBody ResponseEntity<List<UserModel>> getuser(
			) {

		List<UserModel> userlist = new ArrayList<>();
		userlist = userservice.getuserslist();

		return new ResponseEntity<List<UserModel>>(userlist, HttpStatus.OK);
	}
	
	
	
	//Implementing Thrid party api's
	
	@PostMapping("v1/createRzpcontactId")
	public @ResponseBody ResponseEntity<Message> addContactid(@RequestBody UserContactJson userContactJson){
		Message message = new Message();
		
		message = userservice.addContactid(userContactJson);
		if (message.getStatuscode() == 400) {
			return new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
		} else {
			return new ResponseEntity<Message>(message, HttpStatus.OK);
		}
	}
	
	@PostMapping("v1/createBankRefId")
	public @ResponseBody ResponseEntity<Message> addbankId(@RequestBody UserBankAccountJson userBankAccountJson){
		Message message = new Message();
		
		message = userservice.addbankId(userBankAccountJson);
		if (message.getStatuscode() == 400) {
			return new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
		} else {
			return new ResponseEntity<Message>(message, HttpStatus.CREATED);
		}
	}
	

	 @GetMapping(value = "/producer")
	    public String sendMessage(@RequestParam(value="message", required=true) String message)
	    {
		 kafkaTemplate.send("CodeDecodeTopic", message);
	        return "Message sent Successfully to the your code decode topic ";
	    }
	
	 @GetMapping("v1/getuserDetailsbyMob")
		public @ResponseBody ResponseEntity<Easy2moveuserJson> getuserDetails(
				@RequestParam(value = "mobile", required = true) String mobileNo) {

			Easy2moveuserJson userlist = new Easy2moveuserJson();
			userlist = userservice.getuserdetailsbyMob(mobileNo);

			return new ResponseEntity<>(userlist, HttpStatus.OK);
		}
}
