package com.services.easy2move.schedule;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.services.easy2move.service.Easy2moveUserService;

@Component("userBackup")
public class UserBackupScheduller {
private static final Logger LOGGER = LoggerFactory.getLogger(UserBackupScheduller.class);
	
	@Autowired
	private Easy2moveUserService userService;


	  public void handleJdbcMessage(List<Map<String, Object>> message) {
	        for (Map<String, Object> resultMap: message) {
	            for (String column: resultMap.keySet()) {
	            	LOGGER.debug("Payment_Refund_Handler: column: " + column + " value: " + resultMap.get(column));
	            	
	            	String name = (String) resultMap.get("NAME");
	            	String userName = (String) resultMap.get("USERNAME");  
	            	String mobile = (String) resultMap.get("MOBILE_NUMBER");
	            	String email= (String) resultMap.get("EMAIL_ID");
	            	String password = (String) resultMap.get("USER_PASSWORD");  
	            	String city = (String) resultMap.get("CITY");
	            	
	            	userService.userScheduleMethod(name, userName, mobile, email, password, city);
	            }
	            
	        }
	        
	  }
}


