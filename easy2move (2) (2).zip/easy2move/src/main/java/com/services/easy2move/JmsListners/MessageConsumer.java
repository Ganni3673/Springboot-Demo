package com.services.easy2move.JmsListners;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.services.easy2move.json.Easy2moveuserJson;
import com.services.easy2move.service.Easy2moveUserService;

@Component
public class MessageConsumer {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageConsumer.class);

	@Autowired
	private Easy2moveUserService userservice;

	@JmsListener(destination = "myname")
	public void namelistner(String name) {
		userservice.getNamebyMQ(name);
	}
	
	@JmsListener(destination = "userDetails")
	public void listenUserDetails(String Userdetails) {
		Gson gson = new Gson();
		LOGGER.info("Message Recieved from MQ");
		Easy2moveuserJson userjson = gson.fromJson(Userdetails, Easy2moveuserJson.class);
		userservice.userdetailsgettingfromMQ(userjson);
	}
	
	
}
