package com.services.easy2move;

import javax.jms.ConnectionFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.util.ErrorHandler;
import org.springframework.web.client.RestTemplate;

@ComponentScan("com.services.easy2move.controller,com.services.easy2move.service,com.services.easy2move.json,com.services.easy2move.customExceptionMethods,com.services.easy2move.globalexception,com.services.easy2move.config,com.services.easy2move.JmsListners,com.services.easy2move.schedule")
@EnableJpaRepositories("com.services.easy2move.repository")
@EntityScan("com.services.easy2move.model")
@ImportResource({ "classpath:spring/spring-integration-dbpoller-config.xml" })
@SpringBootApplication
public class Easy2moveApplication {

	public static void main(String[] args) {
//ApplicationContext context = new ClassPathXmlApplicationContext("spring/spring-integration-dbpoller-config.xml");
		ConfigurableApplicationContext app = SpringApplication.run(Easy2moveApplication.class, args);
//		for (String string : app.getBeanDefinitionNames()) {
//			System.out.println(string);
//
//		}	
	}

	@Bean
	public JmsListenerContainerFactory<?> myFactory(ConnectionFactory connectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {

		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();

		// anonymous class
		factory.setErrorHandler(new ErrorHandler() {
			@Override
			public void handleError(Throwable t) {
				System.err.println("An error has occurred in the transaction");
			}
		});

		// This provides all boot's default to this factory, including the message
		// converter
		configurer.configure(factory, connectionFactory);
		// You could still override some of Boot's default if necessary.

		return factory;
	}
//	  @SuppressWarnings("deprecation")
//	@Bean
//	    public PasswordEncoder passwordEncoder(){
//	        return NoOpPasswordEncoder.getInstance();
//	    }

	
	 @Bean
	 public RestTemplate restTemplate() {
	     return new RestTemplate();
	 }
}
