package com.services.easy2move.json;

import java.io.Serializable;


public class JwtErrorResponsejson implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;
			
	 private final String message;
		
		private final int statusCode;
		
		public JwtErrorResponsejson(String message, int statusCode ) {
			this.message = message;
			this.statusCode=statusCode;
		}

		public String getMessage() {
			return message;
		}

		public int getStatusCode() {
			return statusCode;
		}

}
