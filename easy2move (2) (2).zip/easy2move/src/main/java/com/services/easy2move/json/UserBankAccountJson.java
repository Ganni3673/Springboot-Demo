package com.services.easy2move.json;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserBankAccountJson {
	
	public String contact_id;
	public  String account_type;
	BankDetailsJson bank_account;

	//go to this url for more information : https://razorpay.com/docs/api/x/fund-accounts
	
	// API
	//POST==== https://api.razorpay.com/v1/fund_accounts
	
	//requestjson
//	{
//		  "contact_id":"cont_00000000000001",
//		  "account_type":"bank_account",
//		  "bank_account":{
//		    "name":"Gaurav Kumar",
//		    "ifsc":"HDFC0000053",
//		    "account_number":"765432123456789"
//		  }
//		}
}


//response json

//{
//	  "id" : "fa_00000000000001",
//	  "entity": "fund_account",
//	  "contact_id" : "cont_00000000000001",
//	  "account_type": "bank_account",
//	  "bank_account": {
//	    "ifsc": "HDFC0000053",
//	    "bank_name": "HDFC Bank",
//	    "name": "Gaurav Kumar",
//	    "account_number": "765432123456789",
//	    "notes": []
//	  },
//	  "active": true,
//	  "batch_id": null,
//	  "created_at": 1543650891
//	}
