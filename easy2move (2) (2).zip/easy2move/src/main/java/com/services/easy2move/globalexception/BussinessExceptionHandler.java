package com.services.easy2move.globalexception;

import java.security.SignatureException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException.Unauthorized;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import com.services.easy2move.customExceptionMethods.UserCustomException;
import com.services.easy2move.json.Message;

import io.jsonwebtoken.ExpiredJwtException;

@ControllerAdvice
public class BussinessExceptionHandler{

	
	@ExceptionHandler(UserCustomException.class)
	public ResponseEntity<Message> customExceptionMethod(UserCustomException ex){
		Message msg = new Message();
		msg.setMessage(ex.getMessage());
		msg.setStatuscode(ex.getStatuscode());
		return new ResponseEntity<Message>(msg, HttpStatus.BAD_REQUEST);

	}
	
	 @ExceptionHandler(value = {ExpiredJwtException.class})
	 public ResponseEntity<Object> handleExpiredJwtException(ExpiredJwtException ex, WebRequest request) {
	 // String requestUri = ((ServletWebRequest)request).getRequest().getRequestURI().toString();
	  Message msg = new Message();
		msg.setMessage(ex.getMessage());
		msg.setStatuscode(403);
	  return new ResponseEntity<>(msg, new HttpHeaders(), HttpStatus.FORBIDDEN);
	 }
	 
	 /**
	  * handlerOtherExceptions handles any unhandled exceptions.
	  */
	
	 
	 @ExceptionHandler(value = {SignatureException.class})
	 public ResponseEntity<Object> handleExceptions(SignatureException ex, WebRequest request) {
	 // String requestUri = ((ServletWebRequest)request).getRequest().getRequestURI().toString();
	  Message msg = new Message();
		msg.setMessage(ex.getMessage());
		msg.setStatuscode(401);
	  return new ResponseEntity<>(msg, new HttpHeaders(), HttpStatus.UNAUTHORIZED);
	 }
	
}
