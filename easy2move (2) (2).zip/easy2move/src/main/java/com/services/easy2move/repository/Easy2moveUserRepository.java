package com.services.easy2move.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.services.easy2move.model.Easy2moveUsermodel;

@Repository
public interface Easy2moveUserRepository extends JpaRepository<Easy2moveUsermodel, Integer> {

	@Query(value="select * from easy2move_users where mobile_number=:mobile" , nativeQuery = true)
	Optional<Easy2moveUsermodel> findbyMobNo(String mobile);
	
	@Query(value="select * from easy2move_users where username=:username" , nativeQuery = true)
	Optional<Easy2moveUsermodel> findbyUserName(String username);
}
