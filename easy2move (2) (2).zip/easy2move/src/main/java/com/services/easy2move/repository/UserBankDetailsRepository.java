package com.services.easy2move.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.services.easy2move.model.UserBankDetailsModel;

@Repository
public interface UserBankDetailsRepository extends JpaRepository<UserBankDetailsModel, Integer> {

	@Query(value="select * from user_accountdetails where mobile_number=:mobile",nativeQuery=true)
	Optional<UserBankDetailsModel> findbyMobile(String mobile);
}
