package com.services.easy2move.json;


public class LoginresponseDetails  {

}
